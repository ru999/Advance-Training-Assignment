module ProductManagement {
	requires java.logging;

}